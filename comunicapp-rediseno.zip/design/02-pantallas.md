# 02 · Pantallas

Cada sección dice: archivo del repo → referencia visual → qué cambia. Los textos de los mockups (nombres, direcciones, kg) son datos de ejemplo; en la app salen de los datos reales.

**Antes:** cuántos toques necesita cada rol para su tarea más frecuente (antes → después).

| Rol | Tarea | Antes | Después |
|---|---|---|---|
| Almacén | Marcar «Área lista» o «Descargada» | 3 (abrir, botón, confirmar) | **1** (botón en la tarjeta; deshacer 6 s) |
| Inspección | Empezar una revisión | 3 (abrir, botón, confirmar) + abrir el formulario | **1** («Revisar ahora») |
| Inspección | Revisar un producto que viene bien | Escribir kg en cada producto | **0** (todo útil por omisión) |
| Chofer | Ir a la siguiente recolección | Abrir la tarjeta, luego Maps | **1** (Maps/Waze en la tarjeta) |
| Admin | Fecha y hora de recolección | Escribir «AAAA-MM-DD HH:MM» | **2** (día + hora) |

---

## Navegación por rol

- Las pantallas raíz de los roles de campo (`driver/index`, `warehouse/index`, `inspection/index`) usan `AppHeader` y `headerShown: false`.
- **Admin:** convierte sus tres pantallas principales en pestañas inferiores (`Tabs` de expo-router): Donaciones (`admin/index`), Usuarios (`admin/users`) y Reportes (`admin/reports`). Barra blanca de 84 de alto más el área segura, con ícono de 24 y etiqueta de 12. La pestaña activa va en `red`. `admin/form` y `donation/[id]` siguen apilándose encima. Revisa la documentación de expo-router de SDK 57 para agrupar rutas (`(tabs)`) sin romper `src/app/index.tsx`, que redirige por rol.
- Las pantallas internas (detalle, formularios, revisión, nota) usan `BackHeader` y `BottomActionBar`.

---

## 01 · Inicio de sesión
`components/login.tsx` → `referencia/Main.html`

Ya especificado en `DISENO_LOGIN.md` (incluido en este paquete). Solo cambia el botón: alto 56 y radio 14. **Sin rol asignado** (`_layout.tsx → Gate`) usa el mismo encabezado del círculo con el logo. Debajo va una tarjeta blanca con «Sin rol asignado» en 22/800, el texto explicativo y los botones «Reintentar» (rojo) y «Cerrar sesión» (secundario).

---

## 02 · Almacén — lista
`app/warehouse/index.tsx` → `referencia/AlmacenInicio.html` (interactivo: prueba la acción y el deshacer)

- **Pestañas** (`SegmentedTabs`) en lugar de los 5 chips:
  - «En camino» = `PICKED_UP`.
  - «Llegó» = `AREA_READY`.
  - «Hoy» = `REQUESTED`/`ASSIGNED` con `isToday(scheduledAt)`.
  - La pestaña inicial es la primera que tenga elementos, en ese orden.
- Bajo las pestañas, a la izquierda, una pista corta por pestaña:
  - En camino: «Prepara el área antes de que llegue el camión».
  - Llegó: «Al terminar de bajar la carga, márcala».
  - Hoy: «Programadas para hoy, aún sin salir».
  - A la derecha, «Actualizado HH:MM».
- **Tarjeta:**
  - Donante (19/800) + `Pill` de hora: «Salió HH:MM» (`pickedUpAt`), «Lista HH:MM» (`areaReadyAt`) o «HOY HH:MM» (`scheduledAt`).
  - Dirección (15 `gray`).
  - Línea con ícono Truck: chofer · «≈N kg · M productos». Usa `statedKgTotal` si existe; si no, suma los ítems `STATED` del detalle precargado; si no hay datos, «Contenido por confirmar».
  - `StatusProgress`.
  - **Botón rojo de 58 dentro de la tarjeta:** «Área de llegada lista» (en camino) o «Marcar descargada» (llegó).
  - En «Hoy» no hay botón; en su lugar, un texto gris en caja: «Aún no sale a recolectar…».
  - Tocar el resto de la tarjeta abre el detalle.
- **Acción con deshacer** (sin `Alert` de confirmación):
  1. Al tocar, actualiza la tarjeta al instante (estado optimista) y muestra `UndoToast`: «Área lista · {donante}» o «Descargada · pasa a Inspección».
  2. **Retrasa el `enqueue` de la transición 6 s.** Si tocan «DESHACER» dentro de ese tiempo, no se encola nada.
  3. Si la app pasa a segundo plano o se sale de la pantalla antes, encola de inmediato (sin perder la acción).
  4. Si por algo la operación ya se encoló y todavía no se envía, «Deshacer» puede usar `discardOp(id)`.
  - No hace falta transición inversa en el backend.
- Estado vacío: ícono de check verde, «Todo al día» y «No hay donaciones en esta pestaña.».

## 03 · Almacén — detalle
`app/donation/[id].tsx` (vista de los roles de campo) → `referencia/AlmacenDetalle.html`

Este orden aplica a todos los roles.

1. **Tarjeta principal:**
   - `Pill` de hora y donante en 26/800.
   - `StatusProgress` grande.
   - Dos mosaicos: «Declarado N kg» y «Productos M» (24/800 sobre fondo `bg`).
   - Chofer con ícono Truck.
2. **«Qué trae»:** lista de ítems declarados con nombre, cantidad + unidad y kg alineados a la derecha (16). Con revisión cerrada, se agrega la sección «Revisión de inspección» con útil/descartado por producto.
3. **Nota del chofer**, con las fotos en miniaturas de 3 columnas (tocar = pantalla completa).
4. **Historial** plegado: «Historial (N movimientos)».
5. **`BottomActionBar`** con la acción del rol (`TRANSITIONS`), que conserva la navegación actual a Nota/Revisión. En Almacén se aplica la misma regla de deshacer que en la lista. Si hay un cambio pendiente, en lugar del botón va el texto: «Tu último cambio se enviará en cuanto haya conexión.».
- **Admin:** las «Acciones de administrador» (editar, forzar estado, cancelar, eliminar) se mueven a un botón «Más acciones» que abre una hoja inferior; cada acción conserva su confirmación actual. «Eliminar» va al final, en `redText`.

## 04 · Almacén — sin conexión
→ `referencia/AlmacenSinConexion.html`

Muestra los estados combinados:
- `SyncBar` oscura.
- Texto de caché: «Mostrando lo guardado a las HH:MM. Puedes seguir trabajando: los cambios se envían solos al volver la señal.».
- Tarjeta con `Pill` «Por enviar» (cuando `pendingStatus(id)` existe) y su estado ya avanzado.
- `UndoToast` con «Guardado. Se enviará al volver la señal».

---

## 05 · Inspección — lista
`app/inspection/index.tsx` → `referencia/InspeccionInicio.html`

- Pestañas: «Por revisar» (`UNLOADED` + `IN_REVISION`) y «Llegando» (`AREA_READY`, solo informativas, sin botón).
- `UNLOADED`: `Pill` «Bajó HH:MM» (`unloadedAt`) y botón rojo **«Revisar ahora»**. El botón encola la transición `UNLOADED → IN_REVISION` (sin `Alert`) y navega a `inspection/review/[id]` en el mismo toque.
- `IN_REVISION`: `Pill` «A medias» y botón secundario «Continuar revisión».
- **Opcional (recomendado):** guarda el borrador de la revisión en el caché (`cacheSet('review-draft:'+id, drafts)`) cada vez que cambia, para no perder el avance si cierran la app. Con el borrador se puede mostrar el progreso «3 de 7 productos revisados». Sin borrador, omite esa barra.

## 06 · Inspección — revisión
`app/inspection/review/[id].tsx` + `components/item-editor.tsx` (modo `REVIEWED`) → `referencia/Revision.html` (interactivo)

Es el cambio más grande en toques. Una tarjeta por producto declarado:

- **Arriba:** nombre (18/800) y, a la derecha, «{cantidad} {unidad} · {kg} kg» declarado.
- **`ChoiceGrid` de 3 opciones** (alto 52):

  | Opción | Colores (seleccionada) | Qué guarda |
  |---|---|---|
  | **Todo útil** (por omisión) | `greenSoft` / `greenText` / borde `green` | `kg = declarado`, `discardedKg = 0` |
  | **Una parte** | `orangeSoft` / `orangeText` / borde `orange` | Abre un `Stepper` «Kg útiles» (±1 kg, el número se puede escribir), que empieza en el 80 % redondeado. Muestra «Descartado: X kg» en `redText`; `discardedKg = declarado − útil` |
  | **Nada sirve** | `redSoft` / `redText` / borde `red` | `kg = 0`, `discardedKg = declarado` |

- Si hay descarte, aparece **«¿Por qué se descarta?»** con chips de `DISCARD_REASONS` (44 de alto; el seleccionado va en `ink` con texto blanco). En la interfaz, «No apto para consumo» se puede acortar a «No apto», guardando el valor completo.
- Botón de texto con ícono Calendar: «Agregar caducidad» (o «Caduca 22 oct»). Abre un selector de fecha nativo y guarda `AAAA-MM-DD` como hoy. Instala el selector con `npx expo install` (revisa qué ofrece `@expo/ui` en SDK 57 antes de agregar otra dependencia).
- Debajo de la lista van «+ Producto que no venía en la nota» (borde punteado; abre el editor completo del producto, sin `sourceItemId`) y «Agregar nota de inspección · opcional» (plegado).
- **`BottomActionBar`:**
  - Totales en vivo: «Útil N kg» en `greenText` y «Descartado N kg» en `redText`.
  - Si falta algún motivo: «Falta el motivo en N producto(s)» en `redText`, con el botón deshabilitado.
  - Botón «Cerrar revisión», que abre la pantalla 07.
- La validación existente (`validateDrafts`) se conserva; solo cambia cómo se llenan los campos.

## 07 · Inspección — confirmar cierre
→ `referencia/RevisionCerrar.html`

Reemplaza el `Alert` de texto por una **hoja inferior** que contiene:
- Título «¿Cerrar la revisión?» y «{donante} · ya no se podrá editar».
- Tres mosaicos: Declarado (neutro), Útil (`greenSoft`) y Descartado (`redSoft`), con números de 24/800.
- Barra de % útil: verde sobre fondo `redSoft`.
- Lista de descartes: producto · motivo · kg.
- Botones «Guardar y cerrar» (rojo, con ícono Check) y «Seguir revisando» (secundario).

Al guardar se llama a `enqueue({kind:'revision',…})` como hoy.

---

## 08 · Chofer — mis recolecciones
`app/driver/index.tsx` → `referencia/ChoferInicio.html`

- Subtítulo del encabezado: «N por recolectar · M hechas hoy».
- **«Siguiente»:** la recolección `ASSIGNED` más próxima (ordena por `scheduledAt`), en una tarjeta grande con:
  - Donante en 22/800, `Pill` de hora, dirección en 16/600 y «Reportado: …» (`requestedContents`).
  - Botones «Google Maps» y «Waze» (secundarios de 56, en 2 columnas) que reusan `MapButtons`.
  - Botón rojo «Registrar recolección» que va **directo** a `driver/pickup/[id]`.
- **«Después»:** el resto en filas compactas de 72 de alto (donante, dirección, hora o «Mañana 9:00», ChevronRight). Tocar abre el detalle.
- «Recolectadas hoy (N)» va plegado, con fondo `greenSoft` y Check.

## 09 · Chofer — detalle
`app/donation/[id].tsx` (rol `DRIVER`) → `referencia/ChoferDetalle.html`

- Tarjeta de encabezado con `Pill` de hora, donante y `StatusProgress` («Asignada a ti»).
- Tarjeta **Dirección**: dirección completa en 19/700 y los botones Maps/Waze.
- Tarjeta con «Lo que dijo el donante al llamar» (`requestedContents`) y «Nota del administrador» (`adminNotes`).
- Una línea gris: «Esta información queda guardada en el teléfono: puedes registrar la nota aunque no haya señal.».
- `BottomActionBar`: «Registrar recolección».

## 10 · Chofer — nota de recolección
`app/driver/pickup/[id].tsx` + `components/item-editor.tsx` (modo `STATED`) + `components/photo.tsx` → `referencia/NotaRecoleccion.html`

Dos pasos numerados en la misma pantalla: **«1 · Qué te entregaron»** y **«2 · Fotos»**.

- **Productos ya agregados:** filas compactas de 64 de alto con «Nombre» y «cantidad unidad · ≈kg · categoría», más un botón de lápiz de 48 para editar (y quitar desde ahí).
- **Editor del producto que se está agregando:** tarjeta con borde 2 `orange`.
  - **Producto:** campo de 54 de alto y, debajo, chips de sugerencias. Usa los nombres más usados en las donaciones guardadas en caché del chofer, o una lista fija corta (Arroz, Frijol, Tortilla, Leche, Pan, Verdura mixta) si no hay historial.
  - **Categoría:** chips de 44. Se muestran las 4 más comunes y «Más…» despliega el resto de `CATEGORIES`. Con «Otro» aparece el campo de categoría personalizada, como hoy.
  - **Cantidad:** `Stepper` de 56 y `ChoiceGrid` de unidades en 3 columnas (`UNITS` + «otra»). La unidad por omisión es **la última usada**.
  - **Kg aproximados:** solo si la unidad no es kg (se mantiene la lógica de `isKg`).
  - Botón oscuro «Guardar y agregar otro». Valida el producto, lo convierte en fila y abre un editor vacío.
- **Fotos:** 3 mosaicos cuadrados:
  - «Firma» (obligatoria): con foto se ve en verde con Check; sin foto, con borde punteado.
  - «Lista (si hay)».
  - «Otra foto» (hasta 5, como hoy).
  - Tocar un mosaico abre la cámara directamente; si ya tiene foto, ofrece Cambiar o Quitar.
- «Agregar nota · opcional» va plegado.
- **`BottomActionBar`:** muestra lo que ya está listo («✓ 3 productos · ≈73 kg», «✓ Firma») o lo que falta en `redText` («Falta la foto de la firma»). Debajo va el botón «Registrar recolección», deshabilitado hasta que haya al menos 1 producto válido y la firma.
- Al registrar, conserva el `enqueue` actual. Cambia el `Alert` por un `UndoToast` sin deshacer («Recolección guardada. Se enviará sola.») y vuelve a la lista.

---

## 11 · Admin — donaciones
`app/admin/index.tsx` → `referencia/AdminInicio.html`

- **3 mosaicos-filtro** arriba (número 24/800 y etiqueta 13/700):
  - «Activas»: no `CLOSED` ni `CANCELLED`.
  - «Sin chofer»: `REQUESTED` sin `driverId`.
  - «Conflicto»: `needsReview`; en `redSoft` y solo si es mayor que 0.
  - El activo lleva borde 2 `ink`.
- Buscador con ícono Search (50 de alto) y una fila de chips con scroll horizontal para el resto de filtros (Hoy, En camino, En revisión, Cerradas, Canceladas, Todas).
- **Tarjeta compacta:** donante (17/800), hora a la derecha, chofer · ≈kg y `StatusProgress` compacto.
  - Si no tiene chofer: borde `redSoft`, `Pill` «Sin chofer» y botón oscuro pequeño «Asignar chofer», que abre el formulario en la sección de chofer.
- Botón flotante rojo «+ Nueva donación» (58 de alto, radio 18), sobre la barra de pestañas.
- `ErrorBox` «Sin conexión…»: se convierte en la `SyncBar` oscura con el texto «Sin conexión. Las funciones de administrador requieren internet.».

## 12 · Admin — nueva donación / editar
`app/admin/form.tsx` → `referencia/AdminFormulario.html`

- **Donante:** campo y debajo «Donantes recientes (llenan la dirección):», con chips de los últimos donantes distintos de `allDonations` (caché `admin:donations`). Tocar uno llena el donante y la dirección.
- **Dirección:** textarea de 2 líneas, con la misma ayuda de Maps.
- **«¿Cuándo?»** (reemplaza el texto «AAAA-MM-DD HH:MM»):
  - `ChoiceGrid` de día: Hoy / Mañana / Otro día (este último abre un selector de fecha).
  - `ChoiceGrid` de hora: 09:00 / 12:00 / 16:00 / Otra (abre un selector de hora).
  - Debajo, la fecha resultante legible («Sábado 18 oct, 12:00»).
  - El valor guardado se arma con el helper `at()` / `toLocalInput` existentes.
- **Chofer:** opciones de 60 de alto con radio visual, nombre y carga del día («2 hoy» / «Libre»: número de donaciones `ASSIGNED` hoy por `driverId`). La última opción, «Asignar después» (borde punteado), equivale a `driverId = null`. Conserva el aviso cuando la donación ya fue recolectada.
- «Lo que dijo el donante · opcional» y «+ Nota para el chofer» (plegado, `adminNotes`).
- `BottomActionBar`: «Crear donación» o «Guardar cambios». Los errores se muestran bajo cada campo como hoy.

## 13 · Admin — usuarios
`app/admin/users.tsx` → `referencia/Usuarios.html`

- Subtítulo del encabezado: «N cuentas · M aún no entra».
- Chips de filtro por rol con contador.
- **Filas de 72 de alto:** avatar con iniciales (44), nombre (16/800), rol (14 `gray`) y `Pill` de estado («Aún no entra», «Deshabilitado»). Las cuentas deshabilitadas van al 60 % de opacidad.
- **Al tocar una fila,** se expande en el mismo lugar (borde 2 `ink`) y muestra:
  - Correo.
  - `ChoiceGrid` de rol en 2 × 2. Al cambiar de rol se aplica al instante con un `UndoToast`.
  - «Deshabilitar» (secundario) y «Eliminar» (texto `redText`, con la confirmación actual).
  - Para la propia cuenta, en lugar de los botones, el texto actual.
- Botón flotante «+ Nuevo usuario», que abre una **hoja inferior** con el formulario actual:
  - Nombre y correo.
  - `ChoiceGrid` de rol.
  - Contraseña temporal generada, con botón «Copiar».
  - Al crear, la hoja muestra los datos para entregar, con «Compartir» (Share API) en lugar de un `Alert`.

## 14 · Admin — reportes
`app/admin/reports.tsx` → `referencia/Reportes.html`

- **Periodo** como `SegmentedTabs`: Semana / Mes / Mes anterior / Fechas (este último abre dos selectores de fecha). Debajo, el rango legible. Se quita el botón «Actualizar» porque recalcula al cambiar.
- **Totales** en mosaicos 2 × 2: Donaciones, Declarado, Útil (`greenSoft`) y % útil.
- **«Kg útiles por categoría»:** barras horizontales de 10 de alto en `orange`, sobre `#F0F0F0`. Se ven las 4 mayores y «Ver todas (N)».
- **«Por donante»:** filas con nombre, número de donaciones y % útil a la derecha.
- **«Motivos de descarte»:** barras en `red`.
- «Exportar CSV» (secundario, con ícono Download) al final; conserva la lógica actual.
- Los valores `[N]`, `[KG]` y `[%]` del mockup son marcadores: salen del cálculo existente.
