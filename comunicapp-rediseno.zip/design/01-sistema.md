# 01 · Sistema de diseño

Referencia visual: `referencia/Componentes.html`.

## Colores (solo los del logo de BAMX, más neutros)

Reemplaza el objeto `C` de `src/components/ui.tsx`:

```ts
export const C = {
  // Marca
  orange: '#DE860B',      // círculo del encabezado, progreso, selección
  orangeSoft: '#FCEFD9',  // fondo de chips/selección naranja
  orangeText: '#8A4B00',  // texto sobre orangeSoft (6:1)
  red: '#CF1226',         // botón principal, pestaña activa, contador
  redSoft: '#FDE8EA',
  redText: '#A30E1F',     // errores y descartes (6.8:1 sobre redSoft)
  green: '#7DB52C',       // hoja del logo: éxito, "cerrada", check
  greenSoft: '#EEF6E3',
  greenText: '#3D6B12',   // texto de éxito (5.7:1)
  // Neutros
  ink: '#2E2E2E',         // texto principal, botón oscuro, barra sin conexión
  gray: '#5C5C5C',        // texto secundario (6.7:1 sobre blanco)
  border: '#E2E2E2',
  borderStrong: '#D6D6D6',// bordes de botones secundarios y chips
  track: '#EAEAEA',       // fondo de pestañas segmentadas
  bg: '#F6F6F6',          // fondo de pantalla y de campos
  card: '#FFFFFF',
  disabledBg: '#E4E4E4',
  undoAccent: '#FFC966',  // texto "DESHACER" sobre ink
};
```

- **Rojo = acción principal** (un solo botón rojo por tarjeta o pantalla). **Naranja = marca, progreso y selección.** Verde solo para confirmación o éxito.
- `STATUS_COLOR` (azul, morado, rosa, cian…) **se deja de usar** en la interfaz. El estado se muestra con `StatusProgress` (ver abajo).
- Quita los emojis de la interfaz (📷, ⚠, ●/○) y usa íconos o controles reales.

## Tipografía

**Plus Jakarta Sans**: `npx expo install @expo-google-fonts/plus-jakarta-sans expo-font`. Cárgala en `_layout.tsx` con `useFonts` y mantén el splash hasta que esté lista. Pesos 400, 500, 600, 700 y 800.

| Uso | Tamaño / peso |
|---|---|
| Título de pantalla (encabezado) | 26 / 800, letterSpacing −0.4 |
| Título de detalle (donante) | 26 / 800 |
| Nombre del donante en tarjeta | 19 / 800 (chofer: 22 en la tarjeta "Siguiente") |
| Título de sección | 18 / 800 |
| Texto de cuerpo | 16 / 500–600 |
| Secundario | 14–15 / 500, color `gray` |
| Etiquetas de campo | 14 / 700 |
| Botón principal | 18 / 700 |
| Chips | 13–14 / 700 |
| Números grandes (kg, totales) | 24–28 / 800 |

No uses texto de menos de 13.

## Medidas

- Margen lateral de pantalla: **20**. Separación entre tarjetas: **12**.
- Tarjeta: fondo blanco, radio **18**, padding **16–18**, sombra suave (`0 2 10 rgba(46,46,46,.05)`; Android `elevation: 1`).
- Campo de texto: alto **52–54**, radio 12, fondo `bg`, borde 1 `border`, texto 16–17. Al enfocar, borde `red` y fondo blanco.
- Botón principal: alto **56–60**, radio 14, fondo `red`, texto blanco 18/700, ícono opcional de 22 a la izquierda.
- Botón secundario: alto 56, radio 14, fondo blanco, borde 1.5 `borderStrong`, texto `ink` 16/700.
- Botón oscuro (acciones de formulario como «Guardar y agregar otro»): fondo `ink`, texto blanco.
- Deshabilitado: fondo `disabledBg`, texto `gray`.
- Chip/píldora: alto 40–44, radio 999. Seleccionado: fondo `ink` y texto blanco (filtros), o `orangeSoft` con borde 2 `orange` (opciones de formulario).
- Área táctil mínima: **48 × 48**. Usa `hitSlop` en íconos pequeños.

## Íconos

`npx expo install react-native-svg`, más `lucide-react-native`. Trazo 1.8–2.4. Los íconos que usan los mockups son Mail, Lock, Eye, EyeOff, Check, ChevronLeft, ChevronDown, ChevronRight, Truck, MapPin, Navigation, ClipboardCheck, ClipboardList, Camera, Plus, Minus, Pencil, Calendar, Search, Users, BarChart3, Package, WifiOff, RefreshCw, AlertCircle, Download y X.

## Componentes compartidos

### `AppHeader` (pantallas de inicio de cada rol)

Reemplaza el encabezado del `Stack` en las pantallas raíz (`headerShown: false`). Alto 132 más el área segura superior.

- Fondo `bg`. Arriba a la derecha va un círculo naranja de radio 130 con centro en (ancho − 18, −30). Dentro lleva 3 anillos blancos (radios 40 / 62 / 86, opacidad .24 / .15 / .09, grosor 1.5) centrados en el botón de cuenta, y un borde `red` de 3. Hazlo con `react-native-svg` usando `ClipPath`, igual que en el login.
- A la izquierda, a 20 del borde: el título (26/800) y debajo el subtítulo (14/500 `gray`). El subtítulo es la fecha de hoy («Sábado 18 de octubre») o un resumen («3 por recolectar · 1 hecha hoy»).
- **Botón de cuenta:** círculo blanco de 48 con las iniciales y sombra, a 20 del borde derecho y montado sobre el borde del círculo naranja. Al tocarlo abre una hoja inferior con el nombre, el correo, el rol y «Cerrar sesión». Conserva la lógica actual de `SignOutButton`, que avisa si hay operaciones pendientes. El texto «Salir» del header desaparece.

### `BackHeader` (pantallas internas)

Alto 104. Lleva un círculo naranja pequeño (radio 92, centro en (ancho + 14, −24), borde `red` de 3), un botón circular blanco de 48 con ChevronLeft (o X en formularios de alta) y, a su lado, el nombre de la pantalla anterior en 17/700 `gray`. El título grande de la pantalla va en el contenido (26/800), no en la barra.

### `SyncBar` (rediseño)

Se muestra debajo del encabezado, dentro del margen de 20, con radio 14 y alto mínimo 48:

| Estado | Fondo / texto | Texto |
|---|---|---|
| Sin conexión | `ink` / blanco + ícono WifiOff | «Sin conexión · N por enviar» |
| Enviando | `orangeSoft` / `orangeText` + RefreshCw | «Enviando N cambios…» |
| Con error | `redSoft` / `redText` + AlertCircle, y «Reintentar» subrayado a la derecha | «1 cambio no se pudo enviar» |
| En línea, sin pendientes | no se muestra | — |

Al tocarla se mantiene la lógica actual (`flush` / diálogo de error / descartar). En línea, junto a las pestañas, se muestra «Actualizado HH:MM» en 13 `gray`, con la hora de la última carga. Si los datos vienen de caché, se muestra «Mostrando lo guardado a las HH:MM…» (reemplaza a `CacheNotice`).

### `StatusProgress` (reemplaza a `StatusBadge`)

- 6 segmentos iguales (grid de 6 columnas, separación 4, alto 6; 8 en el detalle, radio 3) para los pasos `REQUESTED…IN_REVISION`. Los pasos alcanzados van en `orange` y el resto en `border`.
- Debajo va la etiqueta en 14/700 seguida de «· paso N de 6» en 500 `gray`.
- `CLOSED`: los 6 segmentos en `green` y la etiqueta «Cerrada» en `greenText`. `CANCELLED`: sin barra, solo la etiqueta «Cancelada» en `redText`.
- Etiquetas cortas para la interfaz (no cambian los valores en la base de datos): `PICKED_UP` → «En camino», y `ASSIGNED` → «Asignada a ti» cuando la ve el chofer.
- Variante compacta (lista de admin): segmentos de 5 de alto y la etiqueta a la derecha en 13/700.

### `Pill` (chip informativo)

Padding 6 × 10, radio 999, texto 13/700. Variantes:

| Variante | Fondo / texto | Ejemplos |
|---|---|---|
| hora | `orangeSoft` / `orangeText` | «HOY 12:00», «Salió 10:15», «Lista 09:30» |
| neutro | `#F0F0F0` / `ink` | «Por enviar», «A medias», «Aún no entra» |
| alerta | `redSoft` / `redText` | «Conflicto», «Sin chofer», «Deshabilitado» |
| éxito | `greenSoft` / `greenText` | «Enviado» |

### `SegmentedTabs` (pestañas con contador)

Contenedor `track` con radio 14 y padding 4. Cada pestaña mide 50 de alto. La activa va en blanco con sombra suave, texto `ink` 700 y el contador en `red` 800; las inactivas en `gray` 600. Úsalas en lugar de los `Chips` de filtros en Almacén e Inspección, y para el periodo en Reportes.

### `UndoToast`

Barra flotante a 16 de los bordes y 28 sobre el borde inferior (más el área segura). Fondo `ink`, radio 14, alto mínimo 60. Lleva un ícono Check en `green`, el texto blanco 15/600 y el botón «DESHACER» (`undoAccent` 15/800, 44 de alto). Dura **6 s** y se cierra solo. Va en un provider global para que cualquier pantalla pueda llamarla.

### `Stepper` (cantidades)

Botones de − y + de 52–56 × 52–56 (radio 12–14, borde 1.5) con el número en medio a 24/800. El número también se puede tocar para escribirlo con `keyboardType="decimal-pad"`.

### `ChoiceGrid` (opciones de una sola respuesta)

Rejilla de 2, 3 o 4 columnas con botones de 48–52 de alto. El seleccionado va en `orangeSoft` con borde 2 `orange` y texto `orangeText`. Los estados de producto en Revisión usan colores propios (ver `02-pantallas.md`). Úsalo con `accessibilityRole="radio"` y `accessibilityState={{ checked }}`.

### `BottomActionBar`

Barra fija abajo, en blanco con sombra superior y padding 14/20, más el área segura. Contiene el botón principal de la pantalla y, opcionalmente, un resumen arriba (totales, una lista de lo que falta). Se usa en los detalles y formularios. El contenido con scroll deja 120–170 libres al final para que la barra no lo tape.

## Reglas de interacción

- **Una acción principal por tarjeta**, visible sin abrir el detalle.
- **Deshacer en vez de confirmar** para las transiciones de Almacén (son reversibles y frecuentes). Se mantiene la confirmación en las que cierran datos (Cerrar revisión), las destructivas (Eliminar, Cancelar) y las de admin (Forzar estado).
- **Valores por omisión inteligentes:** todo útil en la revisión, la última unidad usada, la próxima hora redonda y los donantes recientes.
- **Validación en vivo cerca del botón:** en vez de una caja de errores después de enviar, la barra inferior muestra qué falta («Falta el motivo en 1 producto») y el botón se habilita en cuanto todo está completo.
- **Recarga automática** al volver a la pantalla (ya existe con `useFocusEffect`). Se quita el texto «Desliza hacia abajo para actualizar», pero el gesto se conserva.
- Ofrece retroalimentación háptica ligera (`expo-haptics`) en las acciones principales y al deshacer.
