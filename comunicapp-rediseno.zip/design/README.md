# Rediseño de ComunicApp — paquete para Claude Code

Este paquete describe el rediseño visual y de usabilidad de **todas las pantallas** de la app móvil (Expo + Amplify) siguiendo el estilo del nuevo login.

**Prioridad:** la app se usa en el almacén y en la calle, con las manos ocupadas y a veces sin señal. Cada decisión busca:

1. **Menos toques.** Las acciones de cada rol se hacen desde la lista, sin entrar al detalle ni pasar por diálogos de confirmación cuando la acción se puede deshacer.
2. **Lectura de un vistazo.** Textos grandes, contraste alto, un solo botón principal por tarjeta y el estado como barra de progreso, no como un color que hay que memorizar.
3. **Objetivos táctiles grandes.** Mínimo 48 × 48; las acciones principales miden 56–60 de alto y están en la zona del pulgar.
4. **Sin conexión sin miedo.** El estado de sincronización siempre se ve, y las acciones se guardan al instante.

## Contenido

| Archivo | Qué es |
|---|---|
| `01-sistema.md` | Colores, tipografía, medidas y componentes compartidos (`components/ui.tsx`, encabezado, barra de sincronización, estado, aviso con deshacer). **Implementar primero.** |
| `02-pantallas.md` | Especificación pantalla por pantalla: archivo del repo, referencia visual, estructura y cambios de comportamiento. |
| `referencia/*.html` | Mockups de cada pantalla (390 × 844 pt, las largas son más altas para mostrar todo el scroll). Son HTML con sintaxis de plantilla (`{{…}}`, `<x-dc>`, `<sc-for>`, `<sc-if>`). Úsalos **solo como referencia visual y de medidas**; no se copian tal cual. |
| `DISENO_LOGIN.md` | Especificación detallada del login (ya aprobada). |
| `bamx-logo.png` | Logo para el login y la pantalla "Sin rol". |

## Orden sugerido (un PR por paso)

1. **Sistema:** tokens, fuente, íconos, componentes base, encabezado y barra de sincronización (`01-sistema.md`). Todas las pantallas cambian de look sin tocar su lógica.
2. **Almacén:** lista con acción en la tarjeta y deshacer.
3. **Inspección:** lista y revisión con «Todo útil / Una parte / Nada sirve».
4. **Chofer:** lista con la siguiente recolección destacada y nota de recolección.
5. **Administrador:** pestañas inferiores, lista, formulario, usuarios y reportes.
6. **Login y Sin rol.**

## Reglas para quien implemente

- Lee `AGENTS.md` del repo: Expo SDK 57. Instala dependencias **solo** con `npx expo install` y revisa la documentación de la versión correcta.
- **No cambies el backend** (`amplify/`), el modelo de datos ni las reglas de transición (`lib/domain.ts → TRANSITIONS`). Todo lo nuevo se resuelve en el cliente.
- Toda escritura de los roles de campo sigue pasando por la cola offline (`lib/offline.ts → enqueue`).
- Textos de la interfaz en español, código en inglés (como ya está el repo).
- Si un comportamiento descrito aquí choca con una limitación real del código, avisa y propone una alternativa antes de improvisar.
