# Diseño de la pantalla de inicio de sesión — ComunicApp (BAMX Guadalajara)

Especificación para implementar el nuevo login en la app móvil (React Native).
Medidas en puntos (dp) sobre un lienzo de referencia de 390 × 844 (iPhone 14/15).
Las pantallas de referencia están en `referencia/login.html` y `referencia/login-error.html`.
Son mockups HTML con sintaxis de plantilla (`{{...}}`, `<x-dc>`, `<sc-if>`). Úsalos solo como referencia visual y de medidas; no los copies tal cual.

## Alcance

- Cambiar **solo la apariencia** de la pantalla de login que ya existe.
- **No tocar** la lógica de autenticación (AWS Amplify / Cognito), la navegación, ni el flujo de "configuración del servidor" si existe. Si el botón de engrane actual se usa para algo importante, avisar antes de quitarlo (el diseño nuevo no lo muestra).
- Mantener los textos en español tal como aparecen aquí.

## Colores (solo los del logo de BAMX)

| Token | Hex | Uso |
|---|---|---|
| `orange` | `#DE860B` | Círculo del encabezado |
| `red` | `#CF1226` | Botón principal, borde de foco, errores, aro del círculo |
| `gray` | `#5C5C5C` | Etiquetas, subtítulo, íconos, texto secundario |
| `ink` | `#2E2E2E` | Título y texto escrito en los campos |
| `bg` | `#F6F6F6` | Fondo de la pantalla y fondo de los campos |
| `border` | `#E2E2E2` | Borde de los campos |
| `white` | `#FFFFFF` | Tarjeta, círculo del logo, texto del botón |
| `disabledBg` | `#E4E4E4` | Botón deshabilitado (texto en `gray`) |
| `placeholder` | `#9A9A9A` | Texto de ejemplo en los campos |

## Tipografía

Plus Jakarta Sans (Google Fonts). En Expo: `@expo-google-fonts/plus-jakarta-sans` (pesos 400, 500, 600, 700). Sin Expo, cargar los .ttf como fuentes del proyecto.

| Elemento | Tamaño | Peso | Color |
|---|---|---|---|
| Título "ComunicApp" | 26 | 700, letterSpacing −0.4 | ink |
| Subtítulo "Banco de Alimentos de Guadalajara" | 14 | 500 | gray |
| Etiquetas "Correo" / "Contraseña" | 13 | 600 | gray |
| Texto en campos | 16 | 500 | ink |
| Botón | 18 | 700 | white |
| Nota inferior y mensaje de error | 13 | 400 / 500, lineHeight 1.5 | gray / red |

## Estructura (de arriba a abajo)

1. **Encabezado** — alto 300, sin márgenes laterales.
   - Círculo naranja `orange` de radio 320, centrado horizontalmente, con su centro 100 por encima del borde superior de la pantalla. Solo se ve su parte inferior (termina en y = 220).
   - Dentro del círculo (recortado por él), 4 anillos blancos concéntricos de grosor 1.5, centrados en el centro del logo (x = mitad, y = 206). Radios y opacidades: 104 / 0.22, 144 / 0.16, 188 / 0.11, 236 / 0.07.
   - Contorno rojo `red` de grosor 4 sobre el borde del círculo naranja.
   - Implementar con `react-native-svg` (`Svg`, `Circle`, `ClipPath`, `Defs`, `G`). Centrar en el ancho real del dispositivo, no fijo a 390.
   - **Círculo del logo**: blanco, diámetro 148, centrado, top 132, sombra suave (≈ `0 6 20 rgba(46,46,46,0.10)`; en Android `elevation: 4`). Dentro va `bamx-logo.png` con 116 de ancho y la proporción original.
2. **Título y subtítulo** — centrados, padding superior 18, separación 4.
3. **Tarjeta del formulario** — fondo blanco, radio 20, margen lateral 20, margen superior 24, padding 24 vertical / 20 horizontal, sombra (≈ `0 8 24 rgba(46,46,46,0.07)`; Android `elevation: 3`), separación entre elementos 16.
   - **Campo Correo**: etiqueta, luego una caja de alto 50, radio 12, fondo `bg`, borde 1 `border`, padding horizontal 14. Lleva un ícono de sobre de 18 (trazo `gray` 1.8) a la izquierda, con separación 10. Placeholder `nombre@bamx.org.mx`. `keyboardType="email-address"`, `autoCapitalize="none"`, `autoComplete="email"`, `textContentType="username"`.
   - **Campo Contraseña**: igual, pero con ícono de candado a la izquierda y, a la derecha, un botón de ojo de 44 × 44 para mostrar u ocultar la contraseña (íconos ojo / ojo tachado de 20). `accessibilityLabel` "Mostrar contraseña" / "Ocultar contraseña". `secureTextEntry` según el estado. `textContentType="password"`.
   - **Botón "Iniciar sesión"**: alto 54, radio 12, ancho completo, margen superior 6.
   - **Nota**: "Las cuentas las crea el administrador. Si olvidaste tu contraseña, pídele que la restablezca." Centrada.
4. No hay pie de página, engrane ni lema.

Los íconos pueden salir de `lucide-react-native` (Mail, Lock, Eye, EyeOff, AlertCircle) con `strokeWidth` 1.8 y color `gray`.

## Estados

- **Campo enfocado**: borde 1 `red`, fondo blanco, halo `rgba(207,18,38,0.12)` de 3 (en RN basta con el borde rojo y el fondo blanco).
- **Botón deshabilitado** (falta correo o contraseña): fondo `disabledBg`, texto `gray`, sin sombra.
- **Botón habilitado**: fondo `red`, texto blanco, sombra `0 6 16 rgba(207,18,38,0.24)`.
- **Cargando**: el botón muestra "Entrando…" (o un `ActivityIndicator` blanco) y queda deshabilitado.
- **Error de acceso** (ver `referencia/login-error.html`): la caja de contraseña pasa a fondo blanco con borde `red` y candado en `red`. Debajo aparece una línea con ícono de alerta de 16 y el texto "Correo o contraseña incorrectos. Inténtalo de nuevo." en `red` 13/500. El error se quita en cuanto el usuario vuelve a escribir.

## Comportamiento

- Envolver en `KeyboardAvoidingView` + `ScrollView` para que el teclado no tape el botón en pantallas chicas.
- Respetar el área segura (`SafeAreaView` / `react-native-safe-area-context`). El círculo naranja puede pasar por detrás de la barra de estado, y en ese caso la barra va con contenido claro (`StatusBar style="light"`).
- Áreas táctiles de al menos 44 × 44.
- Al presionar "siguiente" en el teclado del correo, el foco pasa a la contraseña. "Ir" en la contraseña envía el formulario.
